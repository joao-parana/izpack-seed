#Sample Application 
This is sample application illustrates an [izpack](http://izpack.org/ "Title") installer.